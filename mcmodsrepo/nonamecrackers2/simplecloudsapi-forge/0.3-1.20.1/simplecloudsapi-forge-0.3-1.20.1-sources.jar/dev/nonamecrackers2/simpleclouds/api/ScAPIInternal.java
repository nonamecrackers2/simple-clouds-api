package dev.nonamecrackers2.simpleclouds.api;

import javax.annotation.Nullable;

public class ScAPIInternal
{
	protected static @Nullable SimpleCloudsAPI instance;
	
	public static void _setApi(SimpleCloudsAPI api)
	{
		if (instance != null)
			throw new IllegalStateException("API instance already set");
		instance = api;
	}
}
