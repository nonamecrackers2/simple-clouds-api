package dev.nonamecrackers2.simpleclouds.api;

import dev.nonamecrackers2.simpleclouds.api.common.cloud.region.ScAPICloudRegion;
import dev.nonamecrackers2.simpleclouds.api.common.world.ScAPICloudManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec2;

public interface SimpleCloudsAPI
{
	static SimpleCloudsAPI getApi()
	{
		return ScAPIInternal.instance;
	}
	
	ScAPICloudManager getCloudManager(Level level);
	
	ScAPICloudRegion createCloudRegion(ResourceLocation cloudTypeId, Vec2 movementDirection, float maxSpeed, float accelerationFactor, float posX, float posZ, float radius, float rotation, float stretchFactor, int existsForTicks, int growTicks, int orderWeight);
}
