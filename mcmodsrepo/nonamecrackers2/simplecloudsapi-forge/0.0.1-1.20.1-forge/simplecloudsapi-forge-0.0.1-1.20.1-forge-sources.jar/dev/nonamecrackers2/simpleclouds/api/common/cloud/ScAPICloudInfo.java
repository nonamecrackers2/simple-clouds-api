package dev.nonamecrackers2.simpleclouds.api.common.cloud;

import dev.nonamecrackers2.simpleclouds.api.common.cloud.weather.WeatherType;

public interface ScAPICloudInfo
{
	WeatherType weatherType();
	
	float storminess();
	
	float stormStart();
	
	float stormFadeDistance();
	
	float transparencyFade();
}
