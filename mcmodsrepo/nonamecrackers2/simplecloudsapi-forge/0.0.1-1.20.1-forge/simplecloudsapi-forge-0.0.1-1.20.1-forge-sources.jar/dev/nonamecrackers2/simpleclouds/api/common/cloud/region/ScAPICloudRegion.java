package dev.nonamecrackers2.simpleclouds.api.common.cloud.region;

import org.joml.Matrix2f;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec2;

public interface ScAPICloudRegion
{
	ResourceLocation getCloudTypeId();
	
	int getOrderWeight();
	
	boolean isDead();
	
	Vec2 getMovementDirection();
	
	float getMaxSpeed();
	
	float getAccelerationFactor();
	
	float getPosX(float partialTick);
	
	float getPosZ(float partialTick);
	
	float getRadius(float partialTick);
	
	float getStretch(float partialTick);
	
	float getRotation(float partialTick);
	
	float getPosX();
	
	float getWorldX();
	
	float getPosZ();
	
	float getWorldZ();
	
	float getRadius();
	
	float getWorldRadius();
	
	float getStretch();
	
	float getRotation();
	
	boolean wasPriorVisible();
	
	Matrix2f createTransform(float partialTick);
}
